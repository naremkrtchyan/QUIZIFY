namespace TestingSystemWeb.Models
{
    /// <summary>
    /// Question class.
    /// </summary>
    public class Question
    {
        public string Text { get; set; } = string.Empty;
        public List<AnswerOption> Options { get; set; } = new();
        public int CorrectOptionNumber { get; set; }

        public Question() { }

        public Question(string text, List<AnswerOption> options, int correctOptionNumber)
        {
            Text = text;
            Options = options;
            CorrectOptionNumber = correctOptionNumber;
        }

        public bool IsCorrect(int answerNumber) => answerNumber == CorrectOptionNumber;
    }
}