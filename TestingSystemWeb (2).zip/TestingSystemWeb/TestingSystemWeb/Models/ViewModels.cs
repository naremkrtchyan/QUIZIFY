using System.ComponentModel.DataAnnotations;

namespace TestingSystemWeb.Models.ViewModels
{
    /// <summary>
    /// Login form model.
    /// </summary>
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Username is required")]
        [Display(Name = "Username")]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; } = string.Empty;
    }

    /// <summary>
    /// Registration form model.
    /// </summary>
    public class RegisterViewModel
    {
        [Required(ErrorMessage = "Username is required")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Username must be 3-50 characters")]
        [Display(Name = "Username")]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "Password is required")]
        [StringLength(100, MinimumLength = 4, ErrorMessage = "Password must be at least 4 characters")]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; } = string.Empty;

        [Required(ErrorMessage = "Full name is required")]
        [Display(Name = "Full Name")]
        public string FullName { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Role")]
        public UserRole Role { get; set; } = UserRole.Student;
    }

    /// <summary>
    /// Create test form model.
    /// </summary>
    public class CreateTestViewModel
    {
        [Required(ErrorMessage = "Test title is required")]
        [Display(Name = "Test Title")]
        public string Title { get; set; } = string.Empty;

        public List<QuestionInputModel> Questions { get; set; } = new();
    }

    public class QuestionInputModel
    {
        [Required(ErrorMessage = "Question text is required")]
        public string Text { get; set; } = string.Empty;

        public List<string> Options { get; set; } = new();

        public int CorrectOptionNumber { get; set; } = 1;
    }

    /// <summary>
    /// Take test form model.
    /// </summary>
    public class TakeTestViewModel
    {
        public string TestId { get; set; } = string.Empty;
        public string TestTitle { get; set; } = string.Empty;
        public List<Question> Questions { get; set; } = new();
        public Dictionary<int, int> Answers { get; set; } = new();
    }
}