namespace TestingSystemWeb.Models
{
    /// <summary>
    /// A single answer option.
    /// </summary>
    public class AnswerOption
    {
        public int Number { get; set; }
        public string Text { get; set; } = string.Empty;

        public AnswerOption() { }

        public AnswerOption(int number, string text)
        {
            Number = number;
            Text = text;
        }
    }
}