using TestingSystemWeb.Models;

namespace TestingSystemWeb.Services
{
    /// <summary>
    /// Main class for managing tests and results.
    /// </summary>
    public class TestManager
    {
        private readonly string _testsFile;
        private readonly string _resultsFile;

        private List<Test> _tests;
        private List<Result> _results;

        public TestManager(IWebHostEnvironment env)
        {
            _testsFile = Path.Combine(env.ContentRootPath, "Data", "tests.json");
            _resultsFile = Path.Combine(env.ContentRootPath, "Data", "results.json");

            _tests = JsonStorage.Load<Test>(_testsFile);
            _results = JsonStorage.Load<Result>(_resultsFile);
        }

        // Returns all tests (read-only)
        public IReadOnlyList<Test> GetAllTests() => _tests;

        // Finds a test by its ID
        public Test? GetTestById(string id) =>
            _tests.FirstOrDefault(t => t.Id == id);

        // Adds a new test
        public void AddTest(Test test)
        {
            _tests.Add(test);
            SaveTests();
        }

        // Deletes a test by ID
        public bool DeleteTest(string id)
        {
            var test = GetTestById(id);
            if (test == null) return false;

            _tests.Remove(test);

            // Also remove all results related to this test
            _results.RemoveAll(r => r.TestId == id);

            SaveTests();
            SaveResults();
            return true;
        }

        // Updates an existing test
        public void UpdateTest(Test test)
        {
            var idx = _tests.FindIndex(t => t.Id == test.Id);
            if (idx >= 0)
            {
                _tests[idx] = test;
                SaveTests();
            }
        }

        // Returns all results (read-only)
        public IReadOnlyList<Result> GetAllResults() => _results;

        // Gets results for a specific student
        public IEnumerable<Result> GetResultsByStudent(string username) =>
            _results.Where(r =>
                r.StudentUsername.Equals(username, StringComparison.OrdinalIgnoreCase));

        // Gets results for a specific test
        public IEnumerable<Result> GetResultsByTest(string testId) =>
            _results.Where(r => r.TestId == testId);

        // Adds a new result
        public void AddResult(Result result)
        {
            _results.Add(result);
            SaveResults();
        }

        // Saves tests to JSON file
        private void SaveTests() => JsonStorage.Save(_testsFile, _tests);

        // Saves results to JSON file
        private void SaveResults() => JsonStorage.Save(_resultsFile, _results);
    }
}