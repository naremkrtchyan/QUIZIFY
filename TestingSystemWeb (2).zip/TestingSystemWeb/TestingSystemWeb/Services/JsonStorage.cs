using System.Text.Json;
using System.Text.Encodings.Web;
using System.Text.Unicode;

namespace TestingSystemWeb.Services
{
    /// <summary>
    /// Helper class for reading and writing JSON files.
    /// </summary>
    public static class JsonStorage
    {
        // JSON serialization settings
        private static readonly JsonSerializerOptions Options = new()
        {
            WriteIndented = true, // makes JSON output pretty (with indentation)
            Encoder = JavaScriptEncoder.Create(UnicodeRanges.All) // supports all languages (e.g. Armenian, etc.)
        };

        // Lock object for thread-safe operations (multithreading safety)
        private static readonly object _lock = new();

        // Method to load data from a JSON file
        public static List<T> Load<T>(string filePath)
        {
            lock (_lock) // ensures only one thread can access at a time
            {
                if (!File.Exists(filePath))
                    return new List<T>(); // if file does not exist, return empty list

                try
                {
                    string json = File.ReadAllText(filePath);

                    if (string.IsNullOrWhiteSpace(json))
                        return new List<T>(); // if file is empty

                    // Deserialize JSON into List<T>
                    return JsonSerializer.Deserialize<List<T>>(json, Options) ?? new List<T>();
                }
                catch
                {
                    // in case of error, return empty list
                    return new List<T>();
                }
            }
        }

        // Method to save data into a JSON file
        public static void Save<T>(string filePath, List<T> data)
        {
            lock (_lock)
            {
                string? directory = Path.GetDirectoryName(filePath);

                // create directory if it doesn't exist
                if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                    Directory.CreateDirectory(directory);

                // convert List<T> to JSON string
                string json = JsonSerializer.Serialize(data, Options);

                // write JSON to file
                File.WriteAllText(filePath, json);
            }
        }
    }
}