# Student Testing System — Web Version

An ASP.NET Core MVC (.NET 10) web application designed for creating and conducting educational tests.

## 🌟 Key Features

- **Web ինտերֆեյս** Bootstrap 5-ով (modern, responsive design)
- **Fully English interface** 
- **Cookie-based authentication** (secure login)
- **Role-based authentication** (Authorization)՝ Teacher / Student
- **Data storage in JSON files** (same as console version)
- **Protection against invalid inpup** (CSRF tokens, validation)

## 📁 Project Structure

```
TestingSystemWeb/
├── TestingSystemWeb.csproj
├── Program.cs                          # App configuration
├── appsettings.json
├── Properties/launchSettings.json
│
├── Models/                             # Data models
│   ├── User.cs
│   ├── Test.cs
│   ├── Question.cs
│   ├── AnswerOption.cs
│   ├── Result.cs
│   └── ViewModels.cs                   # Form view models
│
├── Services/                           # Business logic
│   ├── JsonStorage.cs
│   ├── UserService.cs
│   └── TestManager.cs
│
├── Controllers/                        # MVC controllers
│   ├── HomeController.cs
│   ├── AccountController.cs            # Login/Register/Logout
│   ├── TeacherController.cs
│   └── StudentController.cs
│
├── Views/                              # Razor views (HTML + C#)
│   ├── _ViewImports.cshtml
│   ├── _ViewStart.cshtml
│   ├── Shared/_Layout.cshtml           # Main layout
│   ├── Home/Index.cshtml               # Home page
│   ├── Home/Error.cshtml
│   ├── Account/Login.cshtml
│   ├── Account/Register.cshtml
│   ├── Account/AccessDenied.cshtml
│   ├── Teacher/                        # Teacher pages
│   │   ├── Index.cshtml                # List of tests
│   │   ├── Create.cshtml               # Create test
│   │   ├── Details.cshtml              # View test
│   │   ├── Results.cshtml              # All results
│   │   └── TestResults.cshtml          # Results of a single test
│   └── Student/                        # Student pages
│       ├── Index.cshtml                # Available tests
│       ├── Take.cshtml                 # Take a test
│       ├── ResultDetails.cshtml        # Result page
│       └── MyResults.cshtml            # My results
│
├── wwwroot/                            # Static files
│   └── css/site.css
│
└── Data/                               # JSON data files (auto-created)
    ├── users.json
    ├── tests.json
    └── results.json
```

## 🚀 Running the Applicationծարկում

**Requirements՝** .NET 10 SDK

```bash
cd TestingSystemWeb
dotnet run
```

Open in browser՝ **https://localhost:7099** or **http://localhost:5099**

> The browser may warn about the HTTPS certificate (since it is self-signed).
Click "Advanced" → "Proceed anyway" or use HTTP instead.

## 👥 Test Users

| Username | Password | Role |
|-----------|-----------|------|
| `teacher` | `1234` | Դասախոս |
| `student` | `1234` | Ուսանող |

## 📋 Features

### 👨‍🏫 For Teachers
- View all tests (card layout)
- Create new tests with dynamic question addition (JavaScript)
- Add/remove answer options
- View detailed test (questions + correct answers)
- Delete test (cascade delete with results)
- View all student results
- View statistics for a specific test (average, best score)


### 👨‍🎓 For Students
- View available tests
- Take tests with progress tracking
- Get instant results (color-highlighted)
- View personal result history and statistics

## 🛠️ Technologies Used

### Backend
- **C# 13** / **.NET 10**
- **ASP.NET Core MVC** — web framework
- **Cookie Authentication** — authentication system
- **System.Text.Json** — data storage

### Frontend
- **Bootstrap 5.3** — UI framework
- **Bootstrap Icons** — icon set
- **Razor Pages** — server-side templating
- **Vanilla JavaScript** — dynamic forms

## 🎨 Դիզայն

Main design elements:
- Gradient hero section on the home page
- Card-based layout for displaying tests
- Progress bars for results (color-coded by percentage)
- Icons for buttons and sections
- Responsive design (mobile/tablet friendly)

## 🔐 Security

- **CSRF protection** —  `@Html.AntiForgeryToken()` in all POST forms
- **Authorization attribute** — in Teacher/Student controllers 
- **Session expiration** — 2 hours
- **HttpOnly cookies** — not accessible via JavaScript
- **Input validation** — Data Annotations + ModelState

## 📊 Data Storage

All data is stored in JSON format in the Data/ folder:

- `users.json` — users
- `tests.json` — tests
- `results.json` — results

JSON files store Armenian characters using UTF-8 encoding.

## 🔮 Possible Extensions

- Test time limit (timer)
- Randomized question order
- Test editing (Edit functionality)
- Export results to Excel/CSV
- Email notifications (using SendGrid)
- SQL Server or SQLite database
- Test categories
- Admin panel
