using Microsoft.AspNetCore.Mvc;

namespace TestingSystemWeb.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            // If the user is already logged in, redirect to their dashboard
            if (User.Identity?.IsAuthenticated == true)
            {
                return User.IsInRole("Teacher")
                    ? RedirectToAction("Index", "Teacher")
                    : RedirectToAction("Index", "Student");
            }

            return View();
        }

        public IActionResult Error() => View();
    }
}