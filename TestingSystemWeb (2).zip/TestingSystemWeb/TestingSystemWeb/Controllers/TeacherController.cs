using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TestingSystemWeb.Models;
using TestingSystemWeb.Models.ViewModels;
using TestingSystemWeb.Services;

namespace TestingSystemWeb.Controllers
{
    /// <summary>
    /// Pages intended for teachers.
    /// </summary>
    [Authorize(Roles = "Teacher")]
    public class TeacherController : Controller
    {
        private readonly TestManager _testManager;

        public TeacherController(TestManager testManager)
        {
            _testManager = testManager;
        }

        // Main page – list of tests
        public IActionResult Index()
        {
            var tests = _testManager.GetAllTests();
            return View(tests);
        }

        [HttpGet]
        public IActionResult Create()
        {
            // Start with one empty question
            var model = new CreateTestViewModel
            {
                Questions = new List<QuestionInputModel>
                {
                    new() { Options = new List<string> { "", "", "", "" } }
                }
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(CreateTestViewModel model)
        {
            if (string.IsNullOrWhiteSpace(model.Title))
            {
                ModelState.AddModelError(nameof(model.Title), "Test title is required");
                return View(model);
            }

            if (model.Questions == null || model.Questions.Count == 0)
            {
                ModelState.AddModelError(string.Empty, "The test must contain at least one question");
                return View(model);
            }

            var username = User.Identity?.Name ?? "unknown";
            var test = new Test(model.Title, username);

            for (int i = 0; i < model.Questions.Count; i++)
            {
                var q = model.Questions[i];

                if (string.IsNullOrWhiteSpace(q.Text))
                {
                    ModelState.AddModelError(string.Empty, $"Question #{i + 1} text is empty");
                    return View(model);
                }

                var validOptions = q.Options
                    .Where(o => !string.IsNullOrWhiteSpace(o))
                    .Select((text, idx) => new AnswerOption(idx + 1, text.Trim()))
                    .ToList();

                if (validOptions.Count < 2)
                {
                    ModelState.AddModelError(string.Empty,
                        $"Question #{i + 1} must have at least 2 options");
                    return View(model);
                }

                if (q.CorrectOptionNumber < 1 || q.CorrectOptionNumber > validOptions.Count)
                {
                    ModelState.AddModelError(string.Empty,
                        $"Invalid correct answer number for question #{i + 1}");
                    return View(model);
                }

                test.Questions.Add(
                    new Question(q.Text.Trim(), validOptions, q.CorrectOptionNumber));
            }

            _testManager.AddTest(test);
            TempData["SuccessMessage"] = $"Test \"{test.Title}\" was created successfully";

            return RedirectToAction(nameof(Index));
        }

        public IActionResult Details(string id)
        {
            var test = _testManager.GetTestById(id);
            if (test == null) return NotFound();

            return View(test);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(string id)
        {
            if (_testManager.DeleteTest(id))
                TempData["SuccessMessage"] = "Test has been deleted";
            else
                TempData["ErrorMessage"] = "Test not found";

            return RedirectToAction(nameof(Index));
        }

        // All student results
        public IActionResult Results()
        {
            var results = _testManager.GetAllResults()
                .OrderByDescending(r => r.Date)
                .ToList();

            return View(results);
        }

        // Results for a specific test
        public IActionResult TestResults(string id)
        {
            var test = _testManager.GetTestById(id);
            if (test == null) return NotFound();

            var results = _testManager.GetResultsByTest(id)
                .OrderByDescending(r => r.Date)
                .ToList();

            ViewBag.TestTitle = test.Title;

            return View(results);
        }
    }
}