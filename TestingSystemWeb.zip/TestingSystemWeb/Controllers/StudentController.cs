using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TestingSystemWeb.Models;
using TestingSystemWeb.Services;

namespace TestingSystemWeb.Controllers
{
    /// <summary>
    /// Ուսանողի համար նախատեսված էջեր։
    /// </summary>
    [Authorize(Roles = "Student")]
    public class StudentController : Controller
    {
        private readonly TestManager _testManager;

        public StudentController(TestManager testManager)
        {
            _testManager = testManager;
        }

        // Հասանելի թեստերի ցանկ
        public IActionResult Index()
        {
            var tests = _testManager.GetAllTests();
            return View(tests);
        }

        // Թեստի անցկացման էջը (GET)
        [HttpGet]
        public IActionResult Take(string id)
        {
            var test = _testManager.GetTestById(id);
            if (test == null) return NotFound();

            if (test.Questions.Count == 0)
            {
                TempData["ErrorMessage"] = "Այս թեստում հարցեր չկան";
                return RedirectToAction(nameof(Index));
            }

            return View(test);
        }

        // Թեստի պատասխանների ստուգում (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Submit(string testId, Dictionary<int, int> answers)
        {
            var test = _testManager.GetTestById(testId);
            if (test == null) return NotFound();

            int correctCount = 0;
            for (int i = 0; i < test.Questions.Count; i++)
            {
                if (answers != null && answers.TryGetValue(i, out int userAnswer))
                {
                    if (test.Questions[i].IsCorrect(userAnswer))
                        correctCount++;
                }
            }

            var username = User.Identity?.Name ?? "unknown";
            var fullName = User.FindFirst(System.Security.Claims.ClaimTypes.GivenName)?.Value ?? username;

            var result = new Result(
                username, fullName,
                test.Id, test.Title,
                correctCount, test.Questions.Count);

            _testManager.AddResult(result);

            return RedirectToAction(nameof(ResultDetails), new { id = test.Id, correct = correctCount, total = test.Questions.Count });
        }

        // Արդյունքի ցուցադրում
        public IActionResult ResultDetails(string id, int correct, int total)
        {
            var test = _testManager.GetTestById(id);
            if (test == null) return NotFound();

            ViewBag.TestTitle = test.Title;
            ViewBag.Correct = correct;
            ViewBag.Total = total;
            ViewBag.Percentage = total == 0 ? 0 : Math.Round((double)correct / total * 100, 2);

            return View();
        }

        // Իմ նախկին արդյունքները
        public IActionResult MyResults()
        {
            var username = User.Identity?.Name ?? "";
            var results = _testManager.GetResultsByStudent(username)
                .OrderByDescending(r => r.Date)
                .ToList();
            return View(results);
        }
    }
}
