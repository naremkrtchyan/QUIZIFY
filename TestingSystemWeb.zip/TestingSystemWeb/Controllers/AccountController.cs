using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using TestingSystemWeb.Models;
using TestingSystemWeb.Models.ViewModels;
using TestingSystemWeb.Services;

namespace TestingSystemWeb.Controllers
{
    /// <summary>
    /// Մուտք / Գրանցում / Ելք գործողությունները։
    /// </summary>
    public class AccountController : Controller
    {
        private readonly UserService _userService;

        public AccountController(UserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var user = _userService.Login(model.Username, model.Password);
            if (user == null)
            {
                ModelState.AddModelError(string.Empty, "Մուտքանունը կամ գաղտնաբառը սխալ են");
                return View(model);
            }

            // Cookie հաստատում
            var claims = new List<Claim>
            {
                new(ClaimTypes.Name, user.Username),
                new(ClaimTypes.GivenName, user.FullName),
                new(ClaimTypes.Role, user.Role.ToString())
            };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                principal);

            // Ուղղորդում ըստ դերի
            return user.Role == UserRole.Teacher
                ? RedirectToAction("Index", "Teacher")
                : RedirectToAction("Index", "Student");
        }

        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var user = new User(model.Username, model.Password, model.FullName, model.Role);
            if (!_userService.Register(user))
            {
                ModelState.AddModelError(nameof(model.Username),
                    "Այս մուտքանունով օգտատեր արդեն գոյություն ունի");
                return View(model);
            }

            TempData["SuccessMessage"] = "Գրանցումը հաջողվել է։ Այժմ կարող եք մուտք գործել։";
            return RedirectToAction(nameof(Login));
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "Home");
        }

        public IActionResult AccessDenied() => View();
    }
}
