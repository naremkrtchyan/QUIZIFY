using Microsoft.AspNetCore.Mvc;

namespace TestingSystemWeb.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            // Եթե արդեն մուտք է գործել, ուղղորդել իր էջ
            if (User.Identity?.IsAuthenticated == true)
            {
                return User.IsInRole("Teacher")
                    ? RedirectToAction("Index", "Teacher")
                    : RedirectToAction("Index", "Student");
            }
            return View();
        }

        public IActionResult Error() => View();
    }
}
