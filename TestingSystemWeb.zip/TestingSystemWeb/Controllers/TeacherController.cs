using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TestingSystemWeb.Models;
using TestingSystemWeb.Models.ViewModels;
using TestingSystemWeb.Services;

namespace TestingSystemWeb.Controllers
{
    /// <summary>
    /// Դասախոսի համար նախատեսված էջեր։
    /// </summary>
    [Authorize(Roles = "Teacher")]
    public class TeacherController : Controller
    {
        private readonly TestManager _testManager;

        public TeacherController(TestManager testManager)
        {
            _testManager = testManager;
        }

        // Գլխավոր էջ՝ թեստերի ցանկ
        public IActionResult Index()
        {
            var tests = _testManager.GetAllTests();
            return View(tests);
        }

        [HttpGet]
        public IActionResult Create()
        {
            // Մեկ դատարկ հարցով սկսենք
            var model = new CreateTestViewModel
            {
                Questions = new List<QuestionInputModel>
                {
                    new() { Options = new List<string> { "", "", "", "" } }
                }
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(CreateTestViewModel model)
        {
            if (string.IsNullOrWhiteSpace(model.Title))
            {
                ModelState.AddModelError(nameof(model.Title), "Թեստի անվանումը պարտադիր է");
                return View(model);
            }

            if (model.Questions == null || model.Questions.Count == 0)
            {
                ModelState.AddModelError(string.Empty, "Թեստը պետք է ունենա առնվազն մեկ հարց");
                return View(model);
            }

            var username = User.Identity?.Name ?? "unknown";
            var test = new Test(model.Title, username);

            for (int i = 0; i < model.Questions.Count; i++)
            {
                var q = model.Questions[i];
                if (string.IsNullOrWhiteSpace(q.Text))
                {
                    ModelState.AddModelError(string.Empty, $"Հարց #{i + 1}-ի տեքստը դատարկ է");
                    return View(model);
                }

                var validOptions = q.Options
                    .Where(o => !string.IsNullOrWhiteSpace(o))
                    .Select((text, idx) => new AnswerOption(idx + 1, text.Trim()))
                    .ToList();

                if (validOptions.Count < 2)
                {
                    ModelState.AddModelError(string.Empty, $"Հարց #{i + 1}-ը պետք է ունենա առնվազն 2 տարբերակ");
                    return View(model);
                }

                if (q.CorrectOptionNumber < 1 || q.CorrectOptionNumber > validOptions.Count)
                {
                    ModelState.AddModelError(string.Empty,
                        $"Հարց #{i + 1}-ի ճիշտ պատասխանի համարը անվավեր է");
                    return View(model);
                }

                test.Questions.Add(new Question(q.Text.Trim(), validOptions, q.CorrectOptionNumber));
            }

            _testManager.AddTest(test);
            TempData["SuccessMessage"] = $"Թեստ «{test.Title}»-ը հաջողությամբ ստեղծվել է";
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Details(string id)
        {
            var test = _testManager.GetTestById(id);
            if (test == null) return NotFound();
            return View(test);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(string id)
        {
            if (_testManager.DeleteTest(id))
                TempData["SuccessMessage"] = "Թեստը ջնջվել է";
            else
                TempData["ErrorMessage"] = "Թեստը չգտնվեց";

            return RedirectToAction(nameof(Index));
        }

        // Բոլոր ուսանողների արդյունքները
        public IActionResult Results()
        {
            var results = _testManager.GetAllResults()
                .OrderByDescending(r => r.Date)
                .ToList();
            return View(results);
        }

        // Կոնկրետ թեստի արդյունքները
        public IActionResult TestResults(string id)
        {
            var test = _testManager.GetTestById(id);
            if (test == null) return NotFound();

            var results = _testManager.GetResultsByTest(id)
                .OrderByDescending(r => r.Date)
                .ToList();

            ViewBag.TestTitle = test.Title;
            return View(results);
        }
    }
}
