# Ուսանողների թեստավորման համակարգ — Web տարբերակ

ASP.NET Core MVC (.NET 10) վեբ ծրագիր, որը նախատեսված է ուսումնական թեստերի ստեղծման և անցկացման համար։

## 🌟 Հիմնական առանձնահատկություններ

- **Web ինտերֆեյս** Bootstrap 5-ով (արդիական, ադապտիվ դիզայն)
- **Հայերեն ինտերֆեյս** ամբողջությամբ
- **Cookie-based authentication** (անվտանգ մուտք)
- **Դերերի վրա հիմնված մուտք** (Authorization)՝ Teacher / Student
- **JSON ֆայլերում տվյալների պահպանում** (նույնը, ինչ կոնսոլային տարբերակում)
- **Անվավեր մուտքի դեմ պաշտպանություն** (CSRF tokens, validation)

## 📁 Նախագծի կառուցվածքը

```
TestingSystemWeb/
├── TestingSystemWeb.csproj
├── Program.cs                          # App configuration
├── appsettings.json
├── Properties/launchSettings.json
│
├── Models/                             # Տվյալների մոդելներ
│   ├── User.cs
│   ├── Test.cs
│   ├── Question.cs
│   ├── AnswerOption.cs
│   ├── Result.cs
│   └── ViewModels.cs                   # Form view models
│
├── Services/                           # Բիզնես-տրամաբանություն
│   ├── JsonStorage.cs
│   ├── UserService.cs
│   └── TestManager.cs
│
├── Controllers/                        # MVC controllers
│   ├── HomeController.cs
│   ├── AccountController.cs            # Login/Register/Logout
│   ├── TeacherController.cs
│   └── StudentController.cs
│
├── Views/                              # Razor views (HTML + C#)
│   ├── _ViewImports.cshtml
│   ├── _ViewStart.cshtml
│   ├── Shared/_Layout.cshtml           # Կատեգորիալ layout
│   ├── Home/Index.cshtml               # Գլխավոր էջ
│   ├── Home/Error.cshtml
│   ├── Account/Login.cshtml
│   ├── Account/Register.cshtml
│   ├── Account/AccessDenied.cshtml
│   ├── Teacher/                        # Դասախոսի էջեր
│   │   ├── Index.cshtml                # Թեստերի ցանկ
│   │   ├── Create.cshtml               # Թեստի ստեղծում
│   │   ├── Details.cshtml              # Թեստի դիտում
│   │   ├── Results.cshtml              # Բոլոր արդյունքները
│   │   └── TestResults.cshtml          # Մեկ թեստի արդյունքները
│   └── Student/                        # Ուսանողի էջեր
│       ├── Index.cshtml                # Հասանելի թեստեր
│       ├── Take.cshtml                 # Թեստի անցկացում
│       ├── ResultDetails.cshtml        # Արդյունքի էջ
│       └── MyResults.cshtml            # Իմ արդյունքները
│
├── wwwroot/                            # Static ֆայլեր
│   └── css/site.css
│
└── Data/                               # JSON տվյալների ֆայլեր (auto-created)
    ├── users.json
    ├── tests.json
    └── results.json
```

## 🚀 Գործարկում

**Պահանջներ՝** .NET 10 SDK

```bash
cd TestingSystemWeb
dotnet run
```

Բացեք բրաուզերում՝ **https://localhost:7099** կամ **http://localhost:5099**

> Browser-ը կարող է զգուշացնել HTTPS sertificate-ի մասին (քանի որ self-signed է)։ Կտտացրեք "Advanced" → "Proceed anyway"։ Կամ պարզապես օգտագործեք HTTP կապը։

## 👥 Փորձարկման օգտատերեր

| Մուտքանուն | Գաղտնաբառ | Դեր |
|-----------|-----------|------|
| `teacher` | `1234` | Դասախոս |
| `student` | `1234` | Ուսանող |

## 📋 Հնարավորություններ

### 👨‍🏫 Դասախոսի համար
- Բոլոր թեստերի դիտում (քարտերի տեսքով)
- Նոր թեստի ստեղծում՝ դինամիկ հարցերի ավելացմամբ (JavaScript)
- Հարցի համար տարբերակների ավելացում/հեռացում
- Թեստի մանրամասն դիտում (հարցեր + ճիշտ պատասխաններ)
- Թեստի ջնջում (cascade delete՝ արդյունքների հետ միասին)
- Բոլոր ուսանողների արդյունքների դիտում
- Կոնկրետ թեստի արդյունքների վիճակագրությունը (միջին, լավագույն)

### 👨‍🎓 Ուսանողի համար
- Հասանելի թեստերի դիտում
- Թեստի անցկացում՝ ընթացքի ցուցադրումով
- Ակնթարթային արդյունքի ստացում (գունավոր ցուցադրումով)
- Անձնական արդյունքների պատմություն և վիճակագրություն

## 🛠️ Օգտագործված տեխնոլոգիաներ

### Backend
- **C# 13** / **.NET 10**
- **ASP.NET Core MVC** — web framework
- **Cookie Authentication** — մուտքի համակարգ
- **System.Text.Json** — տվյալների պահպանում

### Frontend
- **Bootstrap 5.3** — UI framework
- **Bootstrap Icons** — icon set
- **Razor Pages** — server-side templating
- **Vanilla JavaScript** — դինամիկ ձևեր

## 🎨 Դիզայն

Հիմնական դիզայնի տարրերը՝
- Gradient hero section գլխավոր էջում
- Card-based layout թեստերի ցուցադրման համար
- Progress bars արդյունքների համար (գունավոր՝ ըստ տոկոսի)
- Իկոններ բոլոր կոճակների և բաժինների համար
- Responsive design (հարմարված է mobile/tablet էկրաններին)

## 🔐 Անվտանգություն

- **CSRF protection** — բոլոր POST ձևերում `@Html.AntiForgeryToken()`
- **Authorization attribute** — Teacher/Student controllers-ներում
- **Session expiration** — 2 ժամ
- **HttpOnly cookies** — JavaScript-ից չհասանելի
- **Input validation** — Data Annotations + ModelState

## 📊 Տվյալների պահպանում

Բոլոր տվյալները պահվում են `Data/` պանակում JSON ֆորմատով՝
- `users.json` — օգտատերեր
- `tests.json` — թեստեր
- `results.json` — արդյունքներ

JSON ֆայլերը հայերեն տառերը պահում են UTF-8 ձևաչափով։

## 🔮 Հնարավոր ընդլայնումներ

- Թեստի ժամանակային սահմանափակում (timer)
- Հարցերի պատահական հերթականություն
- Թեստի խմբագրում (Edit գործողություն)
- Արդյունքների արտահանում Excel/CSV-ով
- Email ծանուցումներ (օգտագործելով SendGrid)
- SQL Server կամ SQLite database
- Թեստերի կատեգորիաներ
- Ադմին պանել
