namespace TestingSystemWeb.Models
{
    /// <summary>
    /// Թեստի դաս։
    /// </summary>
    public class Test
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Title { get; set; } = string.Empty;
        public string CreatedBy { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public List<Question> Questions { get; set; } = new();

        public Test() { }

        public Test(string title, string createdBy)
        {
            Title = title;
            CreatedBy = createdBy;
        }
    }
}
