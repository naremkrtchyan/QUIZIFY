namespace TestingSystemWeb.Models
{
    /// <summary>
    /// Օգտատիրոջ դերը համակարգում։
    /// </summary>
    public enum UserRole
    {
        Teacher,
        Student
    }

    /// <summary>
    /// Օգտատիրոջ դաս՝ մուտքանուն, գաղտնաբառ, դեր։
    /// </summary>
    public class User
    {
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public UserRole Role { get; set; }

        public User() { }

        public User(string username, string password, string fullName, UserRole role)
        {
            Username = username;
            Password = password;
            FullName = fullName;
            Role = role;
        }
    }
}
