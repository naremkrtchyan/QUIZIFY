using System.ComponentModel.DataAnnotations;

namespace TestingSystemWeb.Models.ViewModels
{
    /// <summary>
    /// Մուտքի ձևի մոդել։
    /// </summary>
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Մուտքանունը պարտադիր է")]
        [Display(Name = "Մուտքանուն")]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "Գաղտնաբառը պարտադիր է")]
        [DataType(DataType.Password)]
        [Display(Name = "Գաղտնաբառ")]
        public string Password { get; set; } = string.Empty;
    }

    /// <summary>
    /// Գրանցման ձևի մոդել։
    /// </summary>
    public class RegisterViewModel
    {
        [Required(ErrorMessage = "Մուտքանունը պարտադիր է")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Մուտքանունը պետք է լինի 3-50 նիշ")]
        [Display(Name = "Մուտքանուն")]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "Գաղտնաբառը պարտադիր է")]
        [StringLength(100, MinimumLength = 4, ErrorMessage = "Գաղտնաբառը պետք է լինի առնվազն 4 նիշ")]
        [DataType(DataType.Password)]
        [Display(Name = "Գաղտնաբառ")]
        public string Password { get; set; } = string.Empty;

        [Required(ErrorMessage = "Անուն Ազգանունը պարտադիր է")]
        [Display(Name = "Անուն Ազգանուն")]
        public string FullName { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Դեր")]
        public UserRole Role { get; set; } = UserRole.Student;
    }

    /// <summary>
    /// Թեստի ստեղծման ձևի մոդել։
    /// </summary>
    public class CreateTestViewModel
    {
        [Required(ErrorMessage = "Թեստի անվանումը պարտադիր է")]
        [Display(Name = "Թեստի անվանում")]
        public string Title { get; set; } = string.Empty;

        public List<QuestionInputModel> Questions { get; set; } = new();
    }

    public class QuestionInputModel
    {
        [Required(ErrorMessage = "Հարցի տեքստը պարտադիր է")]
        public string Text { get; set; } = string.Empty;

        public List<string> Options { get; set; } = new();

        public int CorrectOptionNumber { get; set; } = 1;
    }

    /// <summary>
    /// Թեստի անցկացման ձևի մոդել։
    /// </summary>
    public class TakeTestViewModel
    {
        public string TestId { get; set; } = string.Empty;
        public string TestTitle { get; set; } = string.Empty;
        public List<Question> Questions { get; set; } = new();
        public Dictionary<int, int> Answers { get; set; } = new();
    }
}
