namespace TestingSystemWeb.Models
{
    /// <summary>
    /// Արդյունքի դաս։
    /// </summary>
    public class Result
    {
        public string StudentUsername { get; set; } = string.Empty;
        public string StudentFullName { get; set; } = string.Empty;
        public string TestId { get; set; } = string.Empty;
        public string TestTitle { get; set; } = string.Empty;
        public int CorrectAnswers { get; set; }
        public int TotalQuestions { get; set; }
        public DateTime Date { get; set; } = DateTime.Now;

        public double Percentage =>
            TotalQuestions == 0 ? 0 : Math.Round((double)CorrectAnswers / TotalQuestions * 100, 2);

        public Result() { }

        public Result(string studentUsername, string studentFullName,
                      string testId, string testTitle,
                      int correctAnswers, int totalQuestions)
        {
            StudentUsername = studentUsername;
            StudentFullName = studentFullName;
            TestId = testId;
            TestTitle = testTitle;
            CorrectAnswers = correctAnswers;
            TotalQuestions = totalQuestions;
        }
    }
}
