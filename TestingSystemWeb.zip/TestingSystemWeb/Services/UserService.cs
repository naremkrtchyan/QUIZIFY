using TestingSystemWeb.Models;

namespace TestingSystemWeb.Services
{
    /// <summary>
    /// Օգտատերերի կառավարման ծառայություն։
    /// </summary>
    public class UserService
    {
        private readonly string _filePath;
        private List<User> _users;

        public UserService(IWebHostEnvironment env)
        {
            _filePath = Path.Combine(env.ContentRootPath, "Data", "users.json");
            _users = JsonStorage.Load<User>(_filePath);

            if (_users.Count == 0)
            {
                _users.Add(new User("teacher", "1234", "Արամ Պետրոսյան", UserRole.Teacher));
                _users.Add(new User("student", "1234", "Անի Հակոբյան", UserRole.Student));
                Save();
            }
        }

        public User? Login(string username, string password)
        {
            return _users.FirstOrDefault(u =>
                u.Username.Equals(username, StringComparison.OrdinalIgnoreCase) &&
                u.Password == password);
        }

        public bool Register(User user)
        {
            if (_users.Any(u => u.Username.Equals(user.Username, StringComparison.OrdinalIgnoreCase)))
                return false;

            _users.Add(user);
            Save();
            return true;
        }

        private void Save() => JsonStorage.Save(_filePath, _users);
    }
}
