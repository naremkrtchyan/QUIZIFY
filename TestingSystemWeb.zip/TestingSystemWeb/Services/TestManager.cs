using TestingSystemWeb.Models;

namespace TestingSystemWeb.Services
{
    /// <summary>
    /// Թեստերի և արդյունքների կառավարման հիմնական դաս։
    /// </summary>
    public class TestManager
    {
        private readonly string _testsFile;
        private readonly string _resultsFile;

        private List<Test> _tests;
        private List<Result> _results;

        public TestManager(IWebHostEnvironment env)
        {
            _testsFile = Path.Combine(env.ContentRootPath, "Data", "tests.json");
            _resultsFile = Path.Combine(env.ContentRootPath, "Data", "results.json");
            _tests = JsonStorage.Load<Test>(_testsFile);
            _results = JsonStorage.Load<Result>(_resultsFile);
        }

        public IReadOnlyList<Test> GetAllTests() => _tests;

        public Test? GetTestById(string id) =>
            _tests.FirstOrDefault(t => t.Id == id);

        public void AddTest(Test test)
        {
            _tests.Add(test);
            SaveTests();
        }

        public bool DeleteTest(string id)
        {
            var test = GetTestById(id);
            if (test == null) return false;

            _tests.Remove(test);
            _results.RemoveAll(r => r.TestId == id);
            SaveTests();
            SaveResults();
            return true;
        }

        public void UpdateTest(Test test)
        {
            var idx = _tests.FindIndex(t => t.Id == test.Id);
            if (idx >= 0)
            {
                _tests[idx] = test;
                SaveTests();
            }
        }

        public IReadOnlyList<Result> GetAllResults() => _results;

        public IEnumerable<Result> GetResultsByStudent(string username) =>
            _results.Where(r => r.StudentUsername.Equals(username, StringComparison.OrdinalIgnoreCase));

        public IEnumerable<Result> GetResultsByTest(string testId) =>
            _results.Where(r => r.TestId == testId);

        public void AddResult(Result result)
        {
            _results.Add(result);
            SaveResults();
        }

        private void SaveTests() => JsonStorage.Save(_testsFile, _tests);
        private void SaveResults() => JsonStorage.Save(_resultsFile, _results);
    }
}
