using System.Text.Json;
using System.Text.Encodings.Web;
using System.Text.Unicode;

namespace TestingSystemWeb.Services
{
    /// <summary>
    /// JSON ֆայլերի ընթերցման և գրման օժանդակ դաս։
    /// </summary>
    public static class JsonStorage
    {
        private static readonly JsonSerializerOptions Options = new()
        {
            WriteIndented = true,
            Encoder = JavaScriptEncoder.Create(UnicodeRanges.All)
        };

        private static readonly object _lock = new();

        public static List<T> Load<T>(string filePath)
        {
            lock (_lock)
            {
                if (!File.Exists(filePath))
                    return new List<T>();

                try
                {
                    string json = File.ReadAllText(filePath);
                    if (string.IsNullOrWhiteSpace(json))
                        return new List<T>();

                    return JsonSerializer.Deserialize<List<T>>(json, Options) ?? new List<T>();
                }
                catch
                {
                    return new List<T>();
                }
            }
        }

        public static void Save<T>(string filePath, List<T> data)
        {
            lock (_lock)
            {
                string? directory = Path.GetDirectoryName(filePath);
                if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                    Directory.CreateDirectory(directory);

                string json = JsonSerializer.Serialize(data, Options);
                File.WriteAllText(filePath, json);
            }
        }
    }
}
